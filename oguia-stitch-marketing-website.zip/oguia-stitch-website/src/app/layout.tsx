import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  metadataBase: new URL("https://oguiachocolates.com"),
  title: {
    default: "O’GUIA Chocolates by DAD’S FARM | Single-Origin Philippine Chocolate",
    template: "%s | O’GUIA Chocolates",
  },
  description: "Discover O’GUIA Chocolates by DAD’S FARM: artisanal, single-origin chocolate rooted in Ma-ayon, Capiz, Philippines. Explore our collection, farm story, and wholesale partnerships.",
  keywords: [
    "O’GUIA Chocolates", "O Guia Chocolates", "DAD’S FARM", "Philippine chocolate",
    "Capiz cacao", "Ma-ayon cacao", "single-origin chocolate Philippines",
    "artisanal chocolate", "Filipino cacao", "wholesale chocolate Philippines",
  ],
  alternates: { canonical: "/" },
  openGraph: {
    type: "website",
    locale: "en_PH",
    siteName: "O’GUIA Chocolates by DAD’S FARM",
    url: "/",
    title: "Artisanal Single-Origin Chocolate Rooted in Capiz",
    description: "From the cacao landscape of Ma-ayon, Capiz, to thoughtful chocolate moments.",
    images: [{ url: "/images/farm-hero.jpg", width: 1020, height: 696, alt: "DAD’S FARM and O’GUIA Chocolates in Capiz" }],
  },
  twitter: {
    card: "summary_large_image",
    title: "O’GUIA Chocolates by DAD’S FARM",
    description: "Artisanal single-origin chocolate rooted in Ma-ayon, Capiz.",
    images: ["/images/farm-hero.jpg"],
  },
  robots: { index: true, follow: true, googleBot: { index: true, follow: true, "max-image-preview": "large" } },
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="en-PH"><body>{children}</body></html>;
}
