"use client";

import { useState } from "react";

const products = [
  { name: "70% Dark", note: "Deep cacao. Balanced finish.", tag: "DARK", color: "dark", detail: "A bold, cacao-forward bar for slow moments." },
  { name: "White & Nibs", note: "Creamy sweetness. Gentle crunch.", tag: "WHITE", color: "white", detail: "A smooth, playful take with a delicate cacao crunch." },
  { name: "Keto Bar", note: "A considered, lower-sugar option.", tag: "KETO", color: "orange", detail: "Made for shoppers looking for another way to enjoy chocolate." },
  { name: "Coffee Melange", note: "Chocolate meets local coffee.", tag: "COFFEE", color: "blue", detail: "A rich pairing inspired by familiar Filipino flavors." },
  { name: "Artisanal Tablea", note: "Traditional cacao, reimagined.", tag: "TABLEA", color: "gold", detail: "A comforting cacao ritual rooted in Filipino tradition." },
  { name: "Cupu Bar", note: "A playful cacao expression.", tag: "SPECIAL", color: "purple", detail: "A limited-style expression for curious chocolate lovers." },
  { name: "The Cacao Select", note: "A thoughtful tasting selection.", tag: "GIFT SET", color: "cream", detail: "A giftable collection for sharing and discovery." },
  { name: "Bonbon Selection", note: "Small-batch chocolate moments.", tag: "BONBONS", color: "pink", detail: "An elegant assortment for celebrations and gifting." },
];

const faqs = [
  ["How do I order O’GUIA Chocolates?", "Contact our team for current product availability, retail orders, and wholesale inquiries."],
  ["Where is DAD’S FARM located?", "DAD’S FARM is rooted in Brgy. Old Guia, Ma-ayon, Capiz, Philippines."],
  ["Do you accept wholesale and partnership inquiries?", "Yes. Use the inquiry form to tell us about your store, hospitality business, distribution network, or partnership idea."],
  ["What does tree-to-bar mean?", "It describes a connected approach to cacao—from growing and post-harvest care through chocolate making and the finished product."],
];

function BrandMark() {
  return <a className="brand" href="#top" aria-label="O’GUIA Chocolates home">
    <span className="brand-name">O’GUIA</span><span className="brand-sub">CHOCOLATES</span>
  </a>;
}

export default function Home() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [openFaq, setOpenFaq] = useState<number | null>(0);
  const [sent, setSent] = useState(false);

  return <>
    <div className="announcement">GROWN WITH CARE · MADE IN CAPIZ · ROOTED IN THE PHILIPPINES</div>
    <header className="site-header" id="top">
      <div className="header-inner">
        <BrandMark />
        <nav className={menuOpen ? "nav nav-open" : "nav"} aria-label="Main navigation">
          <a href="#story" onClick={() => setMenuOpen(false)}>Our story</a>
          <a href="#collection" onClick={() => setMenuOpen(false)}>The collection</a>
          <a href="#tree-to-bar" onClick={() => setMenuOpen(false)}>Tree-to-bar</a>
          <a href="#sustainability" onClick={() => setMenuOpen(false)}>Sustainability</a>
          <a href="#faq" onClick={() => setMenuOpen(false)}>FAQ</a>
          <a className="nav-cta" href="#contact" onClick={() => setMenuOpen(false)}>Inquire <span>↗</span></a>
        </nav>
        <button className="menu-toggle" aria-label="Toggle navigation" aria-expanded={menuOpen} onClick={() => setMenuOpen(!menuOpen)}>
          <span></span><span></span>
        </button>
      </div>
    </header>

    <main>
      <section className="hero">
        <div className="hero-image" role="img" aria-label="Cacao farm and its people"></div>
        <div className="hero-shade"></div>
        <div className="hero-content">
          <div className="eyebrow"><span className="eyebrow-dot"></span> From our farm in Capiz</div>
          <h1>Artisanal Single-Origin<br className="desktop-break" /> Chocolate Rooted in the Soil of <em>Ma-ayon, Capiz</em></h1>
          <p>Crafted from tree to bar, our chocolate brings the character of Philippine cacao to every thoughtful bite.</p>
          <div className="hero-actions">
            <a className="button button-gold" href="#collection">Explore collection <span>↗</span></a>
            <a className="button button-outline" href="#story">The story of DAD’S FARM</a>
          </div>
          <div className="hero-values">
            <span>✳ Single origin</span><span>✳ Artisanal</span><span>✳ Tree-to-bar</span><span>✳ Rooted in Capiz</span>
          </div>
        </div>
        <div className="hero-index">01 <span>/</span> 04</div>
      </section>

      <section className="story section-wrap" id="story">
        <div className="story-photo">
          <img src="/images/farm-hero.jpg" alt="The people and cacao landscape behind DAD’S FARM" />
          <div className="photo-label"><span>Our roots</span><strong>DAD’S FARM · CAPIZ</strong></div>
        </div>
        <div className="story-copy">
          <div className="eyebrow">The people behind the chocolate</div>
          <h2>Nurtured Beneath the Canopy of Western Visayas</h2>
          <p>At DAD’S FARM in Ma-ayon, Capiz, cacao is part of a bigger story—one shaped by the land, the people who care for it, and the belief that meaningful things take time.</p>
          <p>O’GUIA Chocolates brings that story into every bar. We celebrate Philippine cacao through thoughtful craft, a sense of place, and a connection that reaches from the farm to your table.</p>
          <a className="text-link" href="#tree-to-bar">Discover our approach <span>→</span></a>
        </div>
        <div className="story-stamp"><span>GROWN</span><b>IN</b><span>CAPIZ</span></div>
      </section>

      <section className="collection section-wrap" id="collection">
        <div className="section-heading">
          <div><div className="eyebrow">Made for mindful moments</div><h2>Curated Chocolate Collection</h2><p>Hand-crafted, slow-created chocolate expressions from the heart of Capiz.</p></div>
          <a className="button button-small" href="#contact">Explore all products <span>↗</span></a>
        </div>
        <div className="product-grid">
          {products.map((product, i) => <article className="product-card" key={product.name}>
            <div className={`product-art ${product.color}`}>
              <span className="product-tag">{product.tag}</span>
              <div className="wrapper">
                <span className="wrapper-logo">O’GUIA</span><span className="wrapper-line"></span>
                <span className="wrapper-name">{product.name}</span><span className="wrapper-cacao">CHOCOLATES BY DAD’S FARM</span>
                <span className="wrapper-leaf">❧</span>
              </div>
              <span className="product-number">0{i + 1}</span>
            </div>
            <div className="product-info"><div className="product-title-row"><h3>{product.name}</h3><span className="product-arrow">↗</span></div><p>{product.note}</p><span className="product-detail">{product.detail}</span><a href="#contact" className="product-link">Product inquiry <span>→</span></a></div>
          </article>)}
        </div>
      </section>

      <section className="tree section-wrap" id="tree-to-bar">
        <div className="tree-intro"><div className="eyebrow">From the Mayon tree to the bar</div><h2>The Mayon Tree-to-Bar Rhythm</h2><p>From careful growing to considered craft, every stage is part of the experience.</p></div>
        <div className="process-grid">
          {[["01","Sun-dappled Canopy","Cacao grows within a living landscape, alongside the rhythm of the farm."],["02","Careful Harvest","Pods are selected with attention to ripeness, quality, and season."],["03","Slow Fermentation","Post-harvest care helps develop the character of each cacao batch."],["04","Artisan Tempering & Wrapping","Chocolate is finished with care, ready to be shared."]].map(([n,t,d])=><article className="process-card" key={n}><span className="process-number">{n}</span><span className="process-icon">✳</span><h3>{t}</h3><p>{d}</p><span className="process-foot">DAD’S FARM · O’GUIA</span></article>)}
        </div>
      </section>

      <section className="biosphere section-wrap" id="sustainability">
        <div className="biosphere-heading"><div className="eyebrow">Growing with the land</div><h2>Preserving the Capiz Biosphere</h2><p>We believe meaningful chocolate starts with a thoughtful relationship to the land, its resources, and its communities.</p></div>
        <div className="biosphere-grid">
          {[["♧","Regenerative Canopy Harmony","A farm landscape that values biodiversity, shade, and soil health."],["⌘","Direct Visayan Empowerment","Keeping local knowledge, skills, and value connected to the place of origin."],["✳","Pure, Unadulterated Ingredients","A careful approach to ingredients, craft, and the character of cacao."]].map(([icon,t,d])=><article className="biosphere-card" key={t}><span className="biosphere-icon">{icon}</span><h3>{t}</h3><p>{d}</p><span className="card-rule"></span></article>)}
        </div>
      </section>

      <section className="faq-contact section-wrap" id="faq">
        <div className="faq-column"><div className="eyebrow">Good things to know</div><h2>Frequently Inquired</h2><p className="faq-intro">A few notes about our chocolate, our farm, and working together.</p>
          <div className="faq-list">{faqs.map(([q,a],i)=><div className="faq-item" key={q}><button onClick={() => setOpenFaq(openFaq === i ? null : i)} aria-expanded={openFaq === i}><span>{q}</span><span className={openFaq === i ? "faq-plus open" : "faq-plus"}>+</span></button>{openFaq === i && <p>{a}</p>}</div>)}</div>
          <div className="faq-note"><span>✳</span><p><strong>Have another question?</strong><br />We’d love to hear from you.</p></div>
        </div>
        <aside className="contact-card" id="contact"><div className="eyebrow">Let’s start a conversation</div><h3>Wholesale & Partnership Inquiries</h3><p>For wholesale orders, retail partnerships, hospitality, or distribution, send us a note.</p>
          {sent ? <div className="success-message"><strong>Thank you for reaching out.</strong><p>Your inquiry is ready to be connected to our team. Please email dadscacaofarm@gmail.com for a direct response.</p></div> :
          <form onSubmit={(e) => { e.preventDefault(); setSent(true); }}>
            <label>Full name<input required name="name" placeholder="Your name" /></label>
            <label>Email address<input required type="email" name="email" placeholder="you@example.com" /></label>
            <label>Inquiry type<select name="type" defaultValue="Wholesale"><option>Wholesale</option><option>Retail partnership</option><option>Distribution</option><option>General inquiry</option></select></label>
            <label>Message<textarea name="message" rows={3} placeholder="Tell us a little about your inquiry" /></label>
            <button className="button button-gold form-submit" type="submit">Prepare inquiry <span>↗</span></button>
            <p className="form-note">For direct inquiries: <a href="mailto:dadscacaofarm@gmail.com">dadscacaofarm@gmail.com</a></p>
          </form>}
        </aside>
      </section>
    </main>

    <footer className="site-footer">
      <div className="footer-main">
        <div className="footer-brand"><BrandMark /><p>Chocolate with a sense of place.<br />Rooted in Capiz, made to be shared.</p><span className="footer-location">⌖ Brgy. Old Guia, Ma-ayon, Capiz, Philippines</span></div>
        <div className="footer-links"><strong>Explore</strong><a href="#story">Our story</a><a href="#collection">Chocolate collection</a><a href="#tree-to-bar">Tree-to-bar rhythm</a><a href="#sustainability">Sustainability</a></div>
        <div className="footer-links"><strong>Connect</strong><a href="mailto:dadscacaofarm@gmail.com">Email the farm</a><a href="#contact">Wholesale inquiries</a><a href="#contact">Partnerships</a></div>
        <div className="footer-news"><strong>Notes from the farm</strong><p>Product news, seasonal stories, and updates from Capiz.</p><a href="mailto:dadscacaofarm@gmail.com" className="footer-email">Get in touch <span>↗</span></a></div>
      </div>
      <div className="footer-bottom"><span>© {new Date().getFullYear()} O’GUIA CHOCOLATES BY DAD’S FARM</span><span>MA-AYON · CAPIZ · PHILIPPINES</span><a href="#top">Back to top ↑</a></div>
    </footer>
  </>;
}
